// Generated file, do not edit
#ifndef WITH_OSG
#define WITH_OSG
#endif
#ifndef WITH_OSGEARTH
#define WITH_OSGEARTH
#endif
