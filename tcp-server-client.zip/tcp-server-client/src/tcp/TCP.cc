//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
//
// (c) 2017 Christian Timmerer, Alpen-Adria-Universität Klagenfurt / Bitmovin Inc.
//          christian.timmerer@itec.aau.at / christian.timmerer@bitmovin.com
//
// 621.800 (17W) Computer Networks and Network Programming

#include "TCP.h"

#include <omnetpp.h>
#include "../3rdParty/IPv4Address.h"
#include "../3rdParty/IPv6Address.h"
#include "TCPSegment_m.h"
#include "../app/HTTPMsg_m.h"

Define_Module(TCP);

void TCP::initialize() {
}

void TCP::handleMessage(cMessage *msg)
{
	if (msg->arrivedOn("fromApp")) {
		this->handleAppMessage((cPacket*)msg);
	} else if (msg->arrivedOn("fromNet")) {
		this->handleTCPSegment((cPacket*)msg);
	}
}

void TCP::handleAppMessage(cPacket *msg) {
    TCPSegment *tcps = new TCPSegment();
    HTTPMsg *httpMsg = check_and_cast<HTTPMsg*>(msg);
    tcps->encapsulate(httpMsg);
    tcps->setSeq(httpMsg->getSeq());

    if(getParentModule()->getName() == "ClientHost") {
        if(httpMsg->getMethod() == "") {
            if(httpMsg->getResource() == "connect") {
                tcps->setSynB(true);
            } else if(httpMsg->getResource() == "close") {
                tcps->setFinB(true);
                tcps->setAckB(true);
            }
        }
    } else { // "ServerHost"
        tcps->setAckB(true);
    }

    send(tcps, "toNet");
}

void TCP::handleTCPSegment(cPacket *msg) {
    TCPSegment *tcps = check_and_cast<TCPSegment*>(msg);
    HTTPMsg *httpMsg  = check_and_cast<HTTPMsg*>(tcps->decapsulate());
    send(httpMsg, "toApp");
}

